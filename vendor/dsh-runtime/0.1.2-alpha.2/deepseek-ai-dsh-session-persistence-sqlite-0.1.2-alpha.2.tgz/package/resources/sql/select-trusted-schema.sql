PRAGMA trusted_schema;
